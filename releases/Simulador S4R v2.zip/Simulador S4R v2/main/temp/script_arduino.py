import libraries.standard as standard
import libraries.serial as Serial
import libraries.string as String
import graphics.screen_updater as screen_updater
pinSensor = 2
led = 4

def setup():
	global pinSensor
	global led
	pass

def loop():
	global pinSensor
	global led
	pass
